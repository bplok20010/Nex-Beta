require([
	'Nex/Ajax',
	'Nex/container/Container'
]);