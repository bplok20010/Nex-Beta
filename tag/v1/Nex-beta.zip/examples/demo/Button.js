
require(['Nex/button/Button'], function(ct){
  ct.create({
    renderTo : render,
    autoResize : true,
    text : 'Button...',
    width : '25%',
    height : 200,
    callback : function(){
    	alert('btn');
      	//this btn
    }
  });
  ct.create({
    renderTo : render,
    autoResize : true,
    text : 'Button...',
    width : '25%',
    height : 200,
    callback : function(){
    	alert('btn');
      	//this btn
    }
  });
  ct.create({
    renderTo : render,
    autoResize : true,
    text : 'Button...',
    width : '25%',
    height : 200,
    callback : function(){
    	alert('btn');
      	//this btn
    }
  });
  ct.create({
    renderTo : render,
    autoResize : true,
    text : 'Button...',
    width : '25%',
    height : 200,
    callback : function(){
    	alert('btn');
      	//this btn
    }
  });
});