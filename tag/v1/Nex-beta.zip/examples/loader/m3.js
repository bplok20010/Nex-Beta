///console.log('m3');
Define( 'm3',['m4'],function(m4){
	console.log(m4)
	return 'm3'	;
} );