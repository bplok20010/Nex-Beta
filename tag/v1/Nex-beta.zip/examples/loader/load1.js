console.log(1)
Nex.requirePath('data4','data4.php?a.js')
define(['data4','load2'],function(a,b){
		exports('complete load data4,load2');
		console.log( 'complete load data4,load2' )							   
});