console.log('f');
Nex.require(['b','c'],function(){
	console.log('234')	;
});