//定义Event.Index组件
var EventIndex = Nex.define('Event.Index','html');
//导出组件
exports( EventIndex );
//设置组件默认参数
EventIndex.setOptions({
	html : '自定义页面事件'  	 
});