console.log(333);
$define(function(){
	Nex.define('OSC');
	console.log('OSC');
});