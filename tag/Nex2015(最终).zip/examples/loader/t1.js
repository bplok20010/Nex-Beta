$define(['t2','t3'],function(a,b){
	console.log( a,b );	
});