define(function(){
	return 789;	
});