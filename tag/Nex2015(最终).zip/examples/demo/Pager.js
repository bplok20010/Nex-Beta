
require(['Nex/pager/Pager'], function(grid){
	Nex.Create('Nex.Pager',{
			renderTo : render,
						width : 700,
						total : 200
					});	
});