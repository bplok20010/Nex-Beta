define(function(require){
	return Nex;	
});