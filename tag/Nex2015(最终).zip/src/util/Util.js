/*
*Util工具
*Nex.util.Utils
*/
Nex.addUtil('Utils',{

});